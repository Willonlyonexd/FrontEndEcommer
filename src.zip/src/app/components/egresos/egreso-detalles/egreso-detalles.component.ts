import { Component } from '@angular/core';

@Component({
  selector: 'app-egreso-detalles',
  templateUrl: './egreso-detalles.component.html',
  styleUrl: './egreso-detalles.component.css'
})
export class EgresoDetallesComponent {

}
