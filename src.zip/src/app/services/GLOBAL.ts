export const GLOBAL = {
    url: 'http://localhost:3000',
    tallas: ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL'],
    colores: ['Azul', 'Rojo', 'Verde', 'Amarillo', 'Negro', 'Blanco', 'Naranja', 'Cafe', 'Rosado'],
    proovedores: ['ZARA', 'ARMANI', 'HERMES', 'SHEIN'],
    almacenes: ['La Paz', 'Santa Cruz', 'Cochabamba'],
    urlTienda: 'www.mitienda.com'
}

